"""
Setup:
1. uv init --python 3.12 my-agent && cd my-agent && uv add 'browser-use==1.0.8'
2. uv run browser-use login   (or export BROWSER_USE_API_KEY=bu_... from https://cloud.browser-use.com/new-api-key)

Runs on the default model (bu-4.0) in a Browser Use Cloud browser. For a local browser and your own model:
    Agent(task, llm=ChatOpenAI('gpt-6-luna'), browser=Browser('chromium'))   # or Browser('chrome'): your open Chrome
"""

from browser_use import Agent

agent = Agent('Find the number of stars of the following repos: browser-use, playwright, stagehand, react, nextjs')
result = agent.run_sync()
print(result.final_result())
