import { act, fireEvent, screen, waitFor } from "@testing-library/react";
import React from "react";
import { describe, it, expect, vi, beforeEach, onTestFinished } from "vitest";
import { renderWithProviders } from "test-utils";
import type { MessageEvent } from "#/types/agent-server/core";
import { I18nKey } from "#/i18n/declaration";
import { UserAssistantEventMessage } from "#/components/conversation-events/chat/event-message-components/user-assistant-event-message";
import { CustomChatInput } from "#/components/features/chat/custom-chat-input";
import { getConversationState } from "#/utils/conversation-local-storage";
import ConversationService from "#/api/conversation-service/conversation-service.api";
import AgentServerConversationService from "#/api/conversation-service/agent-server-conversation-service.api";
import type { AppConversation } from "#/api/conversation-service/agent-server-conversation-service.types";
import type { DirectConversationInfo } from "#/api/agent-server-adapter";
import {
  useIsMutating,
  useMutation,
  QueryClient,
  QueryClientProvider,
} from "@tanstack/react-query";
import { forkConversationMutationKey } from "#/hooks/mutation/use-fork-conversation";

// Capture the filters the row passes to `useIsMutating` (while still running the
// real hook), so a test can assert the row never subscribes to a shared key.
const { isMutatingFilters } = vi.hoisted(() => ({
  isMutatingFilters: [] as unknown[],
}));

vi.mock("@tanstack/react-query", async (importOriginal) => {
  const actual = await importOriginal<typeof import("@tanstack/react-query")>();
  return {
    ...actual,
    useIsMutating: (filters?: unknown) => {
      isMutatingFilters.push(filters);
      return (actual.useIsMutating as (f?: unknown) => number)(filters);
    },
  };
});

const {
  useActiveBackendMock,
  useOptionalConversationIdMock,
  navigateMock,
  navigationState,
} = vi.hoisted(() => ({
  useActiveBackendMock: vi.fn(),
  useOptionalConversationIdMock: vi.fn(),
  navigateMock: vi.fn(),
  // The route the navigation owner supplies. The fork reads only this (and an
  // optional live getter), never `window.location`.
  navigationState: {
    currentPath: "/",
    getCurrentPath: undefined as (() => string) | undefined,
  },
}));

// These provide test context (backend kind, conversation id, navigation); the
// fork behaviour is exercised through the real hook against a mocked service
// (per the repo convention: mock the service, not the hook).
vi.mock("#/hooks/use-conversation-id", () => ({
  useOptionalConversationId: () => useOptionalConversationIdMock(),
}));

vi.mock("#/contexts/active-backend-context", () => ({
  useActiveBackend: () => useActiveBackendMock(),
}));

vi.mock("#/context/navigation-context", async (importActual) => ({
  ...(await importActual<object>()),
  useNavigation: () => ({
    navigate: navigateMock,
    currentPath: navigationState.currentPath,
    getCurrentPath: navigationState.getCurrentPath,
  }),
}));

// test-utils re-inits i18n with empty resources, so `t()` returns the key —
// which becomes the button's accessible name (aria-label).
const BRANCH_LABEL = I18nKey.CHAT_INTERFACE$BRANCH_FROM_HERE;
const CONVERSATION_ID = "conv-1";
const forkResult = { id: "fork-123" } as DirectConversationInfo;

let forkSpy: ReturnType<typeof vi.spyOn>;
let parentSpy: ReturnType<typeof vi.spyOn>;

const makeEvent = (source: "user" | "agent", id: string): MessageEvent =>
  ({
    id,
    source,
    timestamp: "2024-01-01T00:00:00.000Z",
    llm_message: {
      role: source === "user" ? "user" : "assistant",
      content: [{ type: "text", text: "Hello world" }],
    },
    critic_result: null,
  }) as unknown as MessageEvent;

// A user message with only an image (no text) — parses to an empty string.
const makeImageOnlyEvent = (id: string): MessageEvent =>
  ({
    id,
    source: "user",
    timestamp: "2024-01-01T00:00:00.000Z",
    llm_message: {
      role: "user",
      content: [{ type: "image", image_urls: ["data:image/png;base64,AAAA"] }],
    },
    critic_result: null,
  }) as unknown as MessageEvent;

const renderMessage = (event: MessageEvent) =>
  renderWithProviders(
    <UserAssistantEventMessage
      event={event}
      isLastMessage={false}
      isFromPlanningAgent={false}
    />,
  );

// The fork's saved composer draft, which its composer restores on open.
const forkDraft = () => getConversationState(forkResult.id).draftMessage;

describe("UserAssistantEventMessage — branch action", () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    useActiveBackendMock.mockReset();
    useOptionalConversationIdMock.mockReset();
    navigateMock.mockReset();
    isMutatingFilters.length = 0;
    localStorage.clear();
    // The fork navigates only while the reader is still on the source
    // conversation, which the hook reads from the navigation owner's route.
    navigationState.currentPath = `/conversations/${CONVERSATION_ID}`;
    navigationState.getCurrentPath = undefined;

    useActiveBackendMock.mockReturnValue({
      backend: { kind: "local" },
      orgId: null,
    });
    useOptionalConversationIdMock.mockReturnValue({
      conversationId: CONVERSATION_ID,
    });

    ConversationService.setCurrentConversation(null);

    forkSpy = vi
      .spyOn(AgentServerConversationService, "forkConversation")
      // Modern backend (>= 1.31.0): the fork's HEAD (leaf_event_id) is exactly
      // the requested branch point, confirming the message was excluded.
      .mockImplementation((_source, fromEventId) =>
        Promise.resolve({
          ...forkResult,
          leaf_event_id: fromEventId,
        } as unknown as DirectConversationInfo),
      );
    // Default: the message has a parent (the common case), so edit-mode
    // branches before it.
    parentSpy = vi
      .spyOn(AgentServerConversationService, "getEventParentId")
      .mockResolvedValue("evt-parent");
  });

  it("branches an assistant message inclusively, without a parent lookup or prefill", async () => {
    renderMessage(makeEvent("agent", "evt-agent"));

    // Actions only appear on hover.
    fireEvent.mouseEnter(screen.getByTestId("agent-message"));
    fireEvent.click(screen.getByRole("button", { name: BRANCH_LABEL }));

    await waitFor(() =>
      expect(navigateMock).toHaveBeenCalledWith("/conversations/fork-123"),
    );
    expect(parentSpy).not.toHaveBeenCalled();
    expect(forkSpy).toHaveBeenCalledWith("conv-1", "evt-agent", undefined);
    expect(forkDraft()).toBeNull();
  });

  it("edits a user message: branches at its parent and the fork's composer opens with its text", async () => {
    // jsdom has no innerText, which the composer reads its text from.
    Object.defineProperty(HTMLElement.prototype, "innerText", {
      configurable: true,
      get(this: HTMLElement) {
        return this.textContent ?? "";
      },
    });
    onTestFinished(() => {
      Reflect.deleteProperty(HTMLElement.prototype, "innerText");
    });
    const onSubmit = vi.fn();
    // The real composer stays mounted across the route change, as in the app.
    const page = () => (
      <>
        <UserAssistantEventMessage
          event={makeEvent("user", "evt-user")}
          isLastMessage={false}
          isFromPlanningAgent={false}
        />
        <CustomChatInput onSubmit={onSubmit} />
      </>
    );
    const { rerender } = renderWithProviders(page());

    fireEvent.mouseEnter(screen.getByTestId("user-message"));
    fireEvent.click(screen.getByRole("button", { name: BRANCH_LABEL }));

    await waitFor(() =>
      expect(navigateMock).toHaveBeenCalledWith("/conversations/fork-123"),
    );
    expect(parentSpy).toHaveBeenCalledWith("conv-1", "evt-user");
    expect(forkSpy).toHaveBeenCalledWith("conv-1", "evt-parent", undefined);

    // The router commits the new route after the click handler's own tasks.
    await act(() => new Promise((resolve) => setTimeout(resolve, 0)));
    useOptionalConversationIdMock.mockReturnValue({
      conversationId: "fork-123",
    });
    rerender(page());

    await waitFor(() =>
      expect(screen.getByTestId("chat-input").textContent).toBe("Hello world"),
    );
    expect(onSubmit).not.toHaveBeenCalled();
  });

  it("does not prefill the composer when the message has no parent (inclusive fallback)", async () => {
    parentSpy.mockResolvedValue(undefined);
    renderMessage(makeEvent("user", "evt-user"));

    fireEvent.mouseEnter(screen.getByTestId("user-message"));
    fireEvent.click(screen.getByRole("button", { name: BRANCH_LABEL }));

    await waitFor(() =>
      expect(navigateMock).toHaveBeenCalledWith("/conversations/fork-123"),
    );
    expect(forkSpy).toHaveBeenCalledWith("conv-1", "evt-user", undefined);
    expect(forkDraft()).toBeNull();
  });

  it("titles the fork distinctly from its source conversation", async () => {
    ConversationService.setCurrentConversation({
      id: "conv-1",
      title: "Trip planning",
    } as AppConversation);
    renderMessage(makeEvent("user", "evt-user"));

    fireEvent.mouseEnter(screen.getByTestId("user-message"));
    fireEvent.click(screen.getByRole("button", { name: BRANCH_LABEL }));

    await waitFor(() =>
      expect(forkSpy).toHaveBeenCalledWith(
        "conv-1",
        "evt-parent",
        "Trip planning (branch)",
      ),
    );
  });

  it("does not prefill when the backend ignored from_event_id (older agent-server)", async () => {
    // leaf_event_id != requested branch point => the message was NOT excluded
    // (the fork copied the whole conversation), so prefilling would duplicate.
    forkSpy.mockImplementation(() =>
      Promise.resolve({
        ...forkResult,
        leaf_event_id: "some-other-leaf",
      } as unknown as DirectConversationInfo),
    );
    renderMessage(makeEvent("user", "evt-user"));

    fireEvent.mouseEnter(screen.getByTestId("user-message"));
    fireEvent.click(screen.getByRole("button", { name: BRANCH_LABEL }));

    await waitFor(() =>
      expect(navigateMock).toHaveBeenCalledWith("/conversations/fork-123"),
    );
    expect(forkDraft()).toBeNull();
  });

  it("branches an image-only user message inclusively (keeps the image, no prefill)", async () => {
    renderMessage(makeImageOnlyEvent("evt-img"));

    fireEvent.mouseEnter(screen.getByTestId("user-message"));
    fireEvent.click(screen.getByRole("button", { name: BRANCH_LABEL }));

    // No text to edit → branch at the message (inclusive), no parent lookup,
    // no prefill, so the image is not dropped.
    await waitFor(() =>
      expect(navigateMock).toHaveBeenCalledWith("/conversations/fork-123"),
    );
    expect(forkSpy).toHaveBeenCalledWith("conv-1", "evt-img", undefined);
    expect(parentSpy).not.toHaveBeenCalled();
    expect(forkDraft()).toBeNull();
  });

  it("omits the fork title when the tracked conversation is a different one", async () => {
    // Stale/other conversation in the shared singleton — must not be used.
    ConversationService.setCurrentConversation({
      id: "other-conv",
      title: "Stale title",
    } as AppConversation);
    renderMessage(makeEvent("user", "evt-user"));

    fireEvent.mouseEnter(screen.getByTestId("user-message"));
    fireEvent.click(screen.getByRole("button", { name: BRANCH_LABEL }));

    await waitFor(() =>
      expect(forkSpy).toHaveBeenCalledWith("conv-1", "evt-parent", undefined),
    );
  });

  it("ignores a second click while a fork is already in flight", async () => {
    renderMessage(makeEvent("user", "evt-user"));

    fireEvent.mouseEnter(screen.getByTestId("user-message"));
    const button = screen.getByRole("button", { name: BRANCH_LABEL });
    fireEvent.click(button);
    fireEvent.click(button);

    await waitFor(() => expect(forkSpy).toHaveBeenCalled());
    expect(forkSpy).toHaveBeenCalledTimes(1);
  });

  it("still blocks a second fork after the row is unmounted and remounted", async () => {
    // A virtualized row unmounts when it scrolls out, taking the mutation
    // observer (and its `isPending`) with it. A remounted row must still see
    // the in-flight fork, which it reads from the cache entry via
    // `useIsMutating`. The providers stay mounted, as they do in the app.
    let resolveFork: ((value: DirectConversationInfo) => void) | undefined;
    forkSpy.mockImplementation(
      () =>
        new Promise<DirectConversationInfo>((resolve) => {
          resolveFork = resolve;
        }),
    );
    const Row = ({ mounted }: { mounted: boolean }) =>
      mounted ? (
        <UserAssistantEventMessage
          event={makeEvent("user", "evt-user")}
          isLastMessage={false}
          isFromPlanningAgent={false}
        />
      ) : null;
    // Observes the same cache entry the row reads, so we can wait until the
    // in-flight fork is visible before clicking again.
    const forkKey = forkConversationMutationKey(CONVERSATION_ID);
    const ForkCount = () => (
      <span data-testid="fork-count">
        {useIsMutating({ mutationKey: forkKey })}
      </span>
    );
    // A stable client: the mutation observer created on first mount must live
    // on the same cache the remounted row reads from.
    const client = new QueryClient({
      defaultOptions: {
        queries: { retry: false },
        mutations: { retry: false },
      },
    });
    const tree = (mounted: boolean) => (
      <QueryClientProvider client={client}>
        <Row mounted={mounted} />
        <ForkCount />
      </QueryClientProvider>
    );

    const { rerender } = renderWithProviders(tree(true));
    fireEvent.mouseEnter(screen.getByTestId("user-message"));
    fireEvent.click(screen.getByRole("button", { name: BRANCH_LABEL }));
    await waitFor(() => expect(forkSpy).toHaveBeenCalledTimes(1));
    await waitFor(() =>
      expect(screen.getByTestId("fork-count")).toHaveTextContent("1"),
    );

    rerender(tree(false));
    rerender(tree(true));
    await waitFor(() =>
      expect(screen.getByTestId("fork-count")).toHaveTextContent("1"),
    );

    fireEvent.mouseEnter(screen.getByTestId("user-message"));
    fireEvent.click(screen.getByRole("button", { name: BRANCH_LABEL }));

    // Give the second click a chance to reach the service; it must not.
    await act(() => new Promise((resolve) => setTimeout(resolve, 0)));
    expect(forkSpy).toHaveBeenCalledTimes(1);

    await act(async () => {
      resolveFork?.({ ...forkResult } as DirectConversationInfo);
      await Promise.resolve();
    });
  });

  it("does not block the branch action on a fork of another conversation", async () => {
    // `useIsMutating` matches by mutation-key prefix. An unscoped key would
    // make a fork in conversation B read as "already forking" here and silently
    // skip the click; the key must be scoped to this conversation.
    let resolveOther: ((value: DirectConversationInfo) => void) | undefined;
    forkSpy.mockImplementation(
      () =>
        new Promise<DirectConversationInfo>((resolve) => {
          resolveOther = resolve;
        }),
    );

    const OtherFork = () => {
      // A fork started elsewhere, in a different conversation.
      const { mutate } = useMutation<void, Error, void>({
        mutationKey: forkConversationMutationKey("other-conv"),
        mutationFn: () => new Promise<void>(() => {}),
      });
      React.useEffect(() => {
        mutate();
      }, [mutate]);
      return null;
    };

    renderWithProviders(
      <>
        <OtherFork />
        <UserAssistantEventMessage
          event={makeEvent("user", "evt-user")}
          isLastMessage={false}
          isFromPlanningAgent={false}
        />
      </>,
    );

    fireEvent.mouseEnter(screen.getByTestId("user-message"));
    fireEvent.click(screen.getByRole("button", { name: BRANCH_LABEL }));

    // The click in this conversation must reach the service despite the other
    // conversation's fork being in flight.
    await waitFor(() => expect(forkSpy).toHaveBeenCalledTimes(1));

    await act(async () => {
      resolveOther?.({ ...forkResult } as DirectConversationInfo);
      await Promise.resolve();
    });
  });

  it("hides the branch action on the cloud backend", () => {
    useActiveBackendMock.mockReturnValue({
      backend: { kind: "cloud" },
      orgId: null,
    });

    renderMessage(makeEvent("user", "evt-user"));

    fireEvent.mouseEnter(screen.getByTestId("user-message"));
    expect(
      screen.queryByRole("button", { name: BRANCH_LABEL }),
    ).not.toBeInTheDocument();
  });

  it("hides the branch action outside of a conversation", () => {
    useOptionalConversationIdMock.mockReturnValue({
      conversationId: undefined,
    });

    renderMessage(makeEvent("agent", "evt-agent"));

    fireEvent.mouseEnter(screen.getByTestId("agent-message"));
    expect(
      screen.queryByRole("button", { name: BRANCH_LABEL }),
    ).not.toBeInTheDocument();
  });

  it("does not scope the in-flight-fork check to a shared empty conversation key", () => {
    // Outside a conversation the id is empty. Matching `["fork-conversation",
    // ""]` would make every id-less view share one key, so a fork started in
    // one would read as in-flight in another. The row must not subscribe to
    // that key at all.
    useOptionalConversationIdMock.mockReturnValue({
      conversationId: undefined,
    });

    renderMessage(makeEvent("agent", "evt-agent"));

    expect(isMutatingFilters.length).toBeGreaterThan(0);
    for (const filters of isMutatingFilters) {
      expect(filters).not.toHaveProperty("mutationKey");
    }
  });
});
