import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { AUTOMATION_CATALOG } from "@openhands/extensions/automations";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";
import AutomationService from "#/api/automation-service/automation-service.api";
import { SetupDialog } from "#/components/features/manifest/manifest-setup-dialog";
import type { useNativeGitIntegrations } from "#/hooks/query/use-native-git-integrations";
import { SUPER_ADMIN_SETUP_STEP_EVENT } from "#/components/features/setup-guide/super-admin-setup-step-event";
import { I18nKey } from "#/i18n/declaration";
import type { SetupPrerequisitesResult } from "#/hooks/query/use-manifest-prerequisites";
import type { DeploymentCapabilities, SetupEntry } from "#/manifests/types";
import {
  createSetup,
  createSetupEntry,
} from "../../manifests/manifest-test-data";

/**
 * The dialog is the part of setup that is not pure: it owns the step order, the
 * local check that has to pass before the service is asked anything, what the
 * action is handed, and where a finished setup lands. Each stage it drives has
 * its own test, so those are stubbed here and only the wiring is exercised.
 */
const mocks = vi.hoisted(() => ({
  navigate: vi.fn(),
  runAction: vi.fn(),
  prerequisites: vi.fn(),
  capabilities: vi.fn(),
  llmProfiles: vi.fn(),
  nativeIntegrations: vi.fn(),
  instanceConfig: vi.fn(),
  missingCreateEndpoints: vi.fn<
    (entry: SetupEntry, action?: string | null) => string[]
  >(() => []),
  tracking: {
    trackAutomationSetupOpened: vi.fn(),
    trackAutomationSetupBlocked: vi.fn(),
    trackAutomationSetupValidated: vi.fn(),
    trackAutomationSetupCreated: vi.fn(),
    trackAutomationSetupFailed: vi.fn(),
  },
}));

vi.mock("react-router", async (importOriginal) => ({
  ...(await importOriginal<typeof import("react-router")>()),
  useNavigate: () => mocks.navigate,
}));

// A local backend, where the repository field is a plain input rather than the
// picker only a cloud backend can populate.
vi.mock("#/contexts/active-backend-context", () => ({
  useActiveBackend: () => ({
    backend: { id: "local-1", kind: "local" },
    orgId: null,
  }),
}));

// External deployment configuration is controlled; the availability hook runs for real.
vi.mock("#/hooks/query/use-cloud-integrations-config", () => ({
  useCloudIntegrationsConfig: () => mocks.instanceConfig(),
}));

vi.mock("#/hooks/query/use-manifest-capabilities", () => ({
  useSetupCapabilities: () => mocks.capabilities(),
}));

vi.mock("#/hooks/query/use-manifest-prerequisites", () => ({
  useSetupPrerequisites: () => mocks.prerequisites(),
}));

vi.mock("#/hooks/query/use-agent-profiles", () => ({
  useAgentProfiles: () => ({
    data: { profiles: [{ id: "review-profile", name: "Reviewer" }] },
    isLoading: false,
  }),
}));

vi.mock("#/hooks/query/use-llm-profiles", () => ({
  useLlmProfiles: (options: { enabled?: boolean } = {}) =>
    mocks.llmProfiles(options),
}));

vi.mock("#/hooks/query/use-native-git-integrations", () => ({
  useNativeGitIntegrations: () => mocks.nativeIntegrations(),
}));

// Which endpoints an entry cannot be created without is read off the published
// interface manifest, so a real one that declares them leaves the refusal path
// unreachable. Stubbed so the case states the manifest it is about, rather than
// depending on the packaged manifest continuing not to publish them.
vi.mock("#/manifests/automation-setup", async (importOriginal) => ({
  ...(await importOriginal<typeof import("#/manifests/automation-setup")>()),
  missingCreateEndpoints: mocks.missingCreateEndpoints,
}));

vi.mock("#/manifests/manifest-actions", () => ({
  useSetupAction: () => mocks.runAction,
}));

vi.mock("#/hooks/use-tracking", () => ({
  useTracking: () => mocks.tracking,
}));

vi.mock("#/api/automation-service/automation-service.api", () => ({
  default: { validateDraft: vi.fn() },
}));

const NOTHING_TO_CONNECT: SetupPrerequisitesResult = {
  blockingIntegrations: [],
  warningIntegrations: [],
  isBlocked: false,
  isLoading: false,
};

type NativeGitIntegrations = ReturnType<typeof useNativeGitIntegrations>;

/** A backend with no native git integration to use: local, or cloud with none. */
const NO_NATIVE_INTEGRATIONS: NativeGitIntegrations = {
  getNativeIntegration: () => null,
  builtInIntegrations: null,
  isJiraEnabled: false,
  isLinearEnabled: false,
  isSlackEnabled: false,
  deploymentMode: null,
  isLoading: false,
};

/** An Enterprise instance offering GitHub natively, connected when `connected`. */
function selfHostedGithub(connected: boolean): NativeGitIntegrations {
  return {
    ...NO_NATIVE_INTEGRATIONS,
    deploymentMode: "self_hosted",
    getNativeIntegration: (entryId) =>
      entryId === "github"
        ? { provider: "github", isConnected: connected }
        : null,
  };
}

vi.mock("mermaid", () => ({
  default: {
    initialize: vi.fn(),
    parse: vi.fn().mockResolvedValue({ diagramType: "flowchart" }),
    render: vi.fn().mockResolvedValue({
      svg: '<svg data-testid="entry-diagram-svg"></svg>',
    }),
  },
}));

const ENTRY: SetupEntry = createSetupEntry();
const ENTRY_DIAGRAM = "flowchart TD\n  A --> B";
const CUSTOM_AUTOMATION_ENTRY = AUTOMATION_CATALOG.find(
  (entry) => entry.id === "custom-automation",
) as SetupEntry;

function renderDialog(entry: SetupEntry = ENTRY) {
  const user = userEvent.setup();
  const client = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });
  const dialog = () => (
    <QueryClientProvider client={client}>
      <SetupDialog entry={entry} onClose={vi.fn()} />
    </QueryClientProvider>
  );
  const view = render(dialog());
  return { user, rerender: () => view.rerender(dialog()) };
}

/** Answer the two required fields the entry ships without a default. */
async function fillForm(user: ReturnType<typeof userEvent.setup>) {
  await user.type(
    screen.getByTestId("setup-field-repository"),
    "OpenHands/agent-server-gui",
  );
  await user.type(screen.getByTestId("setup-field-widgetName"), "Widgets");
}

beforeEach(() => {
  vi.clearAllMocks();
  // clearAllMocks resets calls, not implementations, so the one case that
  // stubs a manifest without the bundle endpoints would leak into the rest.
  mocks.missingCreateEndpoints.mockReturnValue([]);
  mocks.instanceConfig.mockReturnValue({ data: undefined });
  mocks.prerequisites.mockReturnValue(NOTHING_TO_CONNECT);
  mocks.nativeIntegrations.mockReturnValue(NO_NATIVE_INTEGRATIONS);
  mocks.capabilities.mockReturnValue({
    capabilities: null,
    supported: "unknown",
    unmet: [],
    isLoading: false,
  });
  mocks.llmProfiles.mockReturnValue({
    data: { profiles: [] },
    isLoading: false,
  });
  vi.mocked(AutomationService.validateDraft).mockResolvedValue({
    valid: true,
    errors: [],
  });
});

/** The same entry once it asks for several repositories. */
const MULTI_REPO_ENTRY: SetupEntry = (() => {
  const { form } = createSetup();
  return createSetupEntry({
    setup: createSetup({
      form: {
        ...form,
        args: {
          ...form.args,
          repository: { ...form.args.repository, multiple: true },
        },
      },
    }),
  });
})();

/** An entry that ships a script bundle rather than a prompt. */
const BUNDLE_ENTRY: SetupEntry = createSetupEntry({
  setup: createSetup({
    prompt: undefined,
    bundle: {
      version: "1.0.0",
      entrypoint: "python3 main.py",
      files: { "main.py": "skills/widget-monitor/scripts/main.py" },
      config: { repos: ["{{form.repository}}"] },
    },
  }),
});

/** A bundle naming the secret that holds its GitHub token, as the GitHub entries do. */
const SECRET_NAME_BUNDLE_ENTRY: SetupEntry = (() => {
  const { form } = createSetup();
  return createSetupEntry({
    setup: createSetup({
      prompt: undefined,
      form: {
        ...form,
        args: {
          ...form.args,
          githubTokenSecret: {
            type: "text",
            label: "GitHub token secret",
            help: "Name of the secret holding the GitHub token.",
            default: "GITHUB_PERSONAL_ACCESS_TOKEN",
            required: true,
          },
        },
      },
      bundle: {
        version: "1.0.0",
        entrypoint: "python3 main.py",
        files: { "main.py": "skills/widget-monitor/scripts/main.py" },
        config: {
          repos: ["{{form.repository}}"],
          github_token_secret: "{{form.githubTokenSecret}}",
        },
      },
    }),
  });
})();

/** A deployment that answered discovery and came up short. */
const UNSUPPORTED = {
  capabilities: null,
  supported: false as const,
  unmet: ["webhookDelivery"],
  isLoading: false,
};

const CRON_ONLY_CAPABILITIES: DeploymentCapabilities = {
  ready: true,
  maxAutomationTimeoutSeconds: 900,
  triggerKinds: ["cron"],
  eventSources: ["github"],
  eventTypes: ["issue_comment.created"],
  triggers: {
    cron: { minIntervalSeconds: 60, timezones: ["UTC"] },
    event: { filterLanguage: "jmespath", filterFunctions: ["icontains"] },
  },
  features: [],
};

const ACTION_CAPABILITIES: DeploymentCapabilities = {
  ...CRON_ONLY_CAPABILITIES,
  triggerKinds: ["cron", "event"],
  features: ["agentProfiles", "presetPrompt", "presetPlugin", "customTarball"],
};

const EVENT_FIRST_MIXED_TRIGGER_ENTRY: SetupEntry = (() => {
  const { form } = createSetup();
  return createSetupEntry({
    setup: createSetup({
      form: {
        ...form,
        triggers: {
          event: {
            source: {
              type: "event-source",
              label: "Event source",
              help: "Where events come from.",
              default: "github",
              required: true,
            },
            on: {
              type: "event-type",
              label: "Event type",
              help: "Which event to watch.",
              default: "issue_comment.created",
              required: true,
            },
            mention: {
              type: "text",
              label: "Mention",
              help: "Text that must appear in the comment.",
              default: "@openhands",
              required: true,
            },
          },
          cron: form.triggers!.cron,
        },
      },
      filter: "icontains(comment.body, '{{form.mention}}')",
    }),
  });
})();

const LLM_PROFILE_ENTRY: SetupEntry = (() => {
  const { form } = createSetup();
  return createSetupEntry({
    setup: createSetup({
      form: {
        ...form,
        args: {
          ...form.args,
          model: {
            type: "llm-profile",
            label: "LLM profile",
            help: "Which saved profile should run this automation.",
            required: false,
          },
        },
      },
    }),
  });
})();

describe("SetupDialog", () => {
  it("does not count unresolved prerequisites as a blocked setup", () => {
    const blocked = {
      ...NOTHING_TO_CONNECT,
      blockingIntegrations: [
        {
          id: "github",
          requirement: { message: "Connect GitHub" },
          entry: null,
        },
      ],
      isBlocked: true,
    };
    mocks.prerequisites.mockReturnValue({ ...blocked, isLoading: true });
    const { rerender } = renderDialog();
    expect(mocks.tracking.trackAutomationSetupBlocked).not.toHaveBeenCalled();

    mocks.prerequisites.mockReturnValue(NOTHING_TO_CONNECT);
    rerender();
    expect(mocks.tracking.trackAutomationSetupBlocked).not.toHaveBeenCalled();

    mocks.prerequisites.mockReturnValue(blocked);
    rerender();
    rerender();
    expect(
      mocks.tracking.trackAutomationSetupBlocked,
    ).toHaveBeenCalledExactlyOnceWith({
      automationId: ENTRY.id,
      stage: "prerequisites",
      reason: "github",
      errorCode: "prerequisites_blocked",
    });
  });

  it("does not count an initial action that discovery replaces as unsupported", () => {
    const entry = createSetupEntry({
      setup: createSetup({
        actions: {
          upload: {
            label: "Upload",
            help: "Upload a bundle",
            features: [],
            args: {},
            tarballPath: "bundle.tar.gz",
            entrypoint: "python main.py",
          },
          prompt: {
            label: "Prompt",
            help: "Run a prompt",
            features: [],
            args: {},
            prompt: "Watch widgets",
          },
        },
      }),
    });
    mocks.missingCreateEndpoints.mockImplementation((_entry, action) =>
      action === "upload" ? ["uploads"] : [],
    );
    mocks.capabilities.mockReturnValue({
      ...UNSUPPORTED,
      supported: "unknown",
      isLoading: true,
    });
    const { rerender } = renderDialog(entry);
    expect(mocks.tracking.trackAutomationSetupBlocked).not.toHaveBeenCalled();

    mocks.capabilities.mockReturnValue({
      capabilities: ACTION_CAPABILITIES,
      supported: true,
      unmet: [],
      isLoading: false,
    });
    rerender();
    expect(screen.getByTestId("setup-field-widgetName")).toBeInTheDocument();
    expect(mocks.tracking.trackAutomationSetupBlocked).not.toHaveBeenCalled();
  });

  it("waits for capability discovery before counting an unsupported setup", () => {
    mocks.capabilities.mockReturnValue({ ...UNSUPPORTED, isLoading: true });
    const { rerender } = renderDialog();
    expect(mocks.tracking.trackAutomationSetupBlocked).not.toHaveBeenCalled();

    mocks.capabilities.mockReturnValue(UNSUPPORTED);
    rerender();
    rerender();
    expect(
      mocks.tracking.trackAutomationSetupBlocked,
    ).toHaveBeenCalledExactlyOnceWith({
      automationId: ENTRY.id,
      stage: "prerequisites",
      reason: "webhookDelivery",
      errorCode: "unsupported",
    });
  });

  it("offers agent profiles only for actions that accept them", async () => {
    mocks.capabilities.mockReturnValue({
      capabilities: ACTION_CAPABILITIES,
      supported: true,
      unmet: [],
      isLoading: false,
    });
    const { user } = renderDialog(CUSTOM_AUTOMATION_ENTRY);

    await waitFor(() =>
      expect(screen.getByTestId("setup-action-kind")).toBeInTheDocument(),
    );
    expect(
      screen.queryByTestId("automation-agent-profile"),
    ).not.toBeInTheDocument();

    await user.click(screen.getByTestId("setup-action-kind"));
    await user.click(await screen.findByText("Upload tarball"));
    await waitFor(() =>
      expect(
        screen.getByTestId("automation-agent-profile"),
      ).toBeInTheDocument(),
    );

    await user.click(screen.getByTestId("automation-agent-profile"));
    await user.click(await screen.findByText("Reviewer"));
    await user.click(screen.getByTestId("setup-action-kind"));
    await user.click(await screen.findByText("Prompt"));

    await waitFor(() => {
      expect(
        screen.queryByTestId("automation-agent-profile"),
      ).not.toBeInTheDocument();
      expect(screen.getByTestId("setup-field-model")).toBeInTheDocument();
    });
  });

  it("shows Default after a pass through Prompt and back to Upload tarball", async () => {
    mocks.capabilities.mockReturnValue({
      capabilities: ACTION_CAPABILITIES,
      supported: true,
      unmet: [],
      isLoading: false,
    });
    const { user } = renderDialog(CUSTOM_AUTOMATION_ENTRY);

    await waitFor(() =>
      expect(screen.getByTestId("setup-action-kind")).toBeInTheDocument(),
    );
    await user.click(screen.getByTestId("setup-action-kind"));
    await user.click(await screen.findByText("Upload tarball"));
    await screen.findByTestId("automation-agent-profile");

    // The pass through Prompt clears the profile; back on Upload tarball the
    // field must read Default rather than blank.
    await user.click(screen.getByTestId("setup-action-kind"));
    await user.click(await screen.findByText("Prompt"));
    await waitFor(() =>
      expect(
        screen.queryByTestId("automation-agent-profile"),
      ).not.toBeInTheDocument(),
    );
    await user.click(screen.getByTestId("setup-action-kind"));
    await user.click(await screen.findByText("Upload tarball"));

    const selector = await screen.findByTestId("automation-agent-profile");
    await waitFor(() =>
      expect(selector).toHaveValue(I18nKey.SETTINGS$PROFILE_DEFAULT),
    );
    await user.click(selector);
    expect(
      await screen.findByRole("option", {
        name: I18nKey.SETTINGS$PROFILE_DEFAULT,
      }),
    ).toHaveAttribute("aria-selected", "true");
  });

  it("keeps Default selected after choosing it from the list", async () => {
    mocks.capabilities.mockReturnValue({
      capabilities: ACTION_CAPABILITIES,
      supported: true,
      unmet: [],
      isLoading: false,
    });
    const { user } = renderDialog(CUSTOM_AUTOMATION_ENTRY);

    await waitFor(() =>
      expect(screen.getByTestId("setup-action-kind")).toBeInTheDocument(),
    );
    await user.click(screen.getByTestId("setup-action-kind"));
    await user.click(await screen.findByText("Upload tarball"));

    // Choose a saved profile first, so the return to Default is a real
    // selection change rather than the form's initial state.
    const selector = await screen.findByTestId("automation-agent-profile");
    await user.click(selector);
    await user.click(await screen.findByText("Reviewer"));
    await waitFor(() => expect(selector).toHaveValue("Reviewer"));

    await user.click(selector);
    await user.click(await screen.findByText(I18nKey.SETTINGS$PROFILE_DEFAULT));
    await waitFor(() =>
      expect(selector).toHaveValue(I18nKey.SETTINGS$PROFILE_DEFAULT),
    );
  });

  it("asks about an unconnected integration before it asks anything else", async () => {
    // Arrange — an advisory integration, which is shown but does not block.
    mocks.prerequisites.mockReturnValue({
      ...NOTHING_TO_CONNECT,
      warningIntegrations: [
        {
          id: "github",
          requirement: { message: "Used to read widgets.", required: false },
          entry: null,
        },
      ],
    });
    const { user } = renderDialog();

    // Act
    expect(screen.getByTestId("setup-prerequisites")).toBeInTheDocument();
    await user.click(screen.getByTestId("setup-continue-button"));

    // Assert
    expect(screen.getByTestId("setup-field-widgetName")).toBeInTheDocument();
    expect(screen.queryByTestId("setup-prerequisites")).toBeNull();
  });

  it("hides trigger variants unsupported by the deployment", async () => {
    mocks.capabilities.mockReturnValue({
      capabilities: CRON_ONLY_CAPABILITIES,
      supported: true,
      unmet: [],
      isLoading: false,
    });
    mocks.runAction.mockResolvedValue({ response: { id: "automation-1" } });
    const { user } = renderDialog(EVENT_FIRST_MIXED_TRIGGER_ENTRY);

    await waitFor(() =>
      expect(screen.getByTestId("setup-field-schedule")).toBeInTheDocument(),
    );
    expect(screen.queryByTestId("setup-trigger-kind")).toBeNull();
    expect(screen.queryByTestId("setup-field-source")).toBeNull();
    await fillForm(user);

    await user.click(screen.getByTestId("setup-continue-button"));
    await waitFor(() =>
      expect(screen.getByTestId("setup-review")).toBeInTheDocument(),
    );
    await user.click(screen.getByTestId("setup-continue-button"));

    await waitFor(() => expect(mocks.runAction).toHaveBeenCalled());
    expect(mocks.runAction.mock.calls[0][2]).toEqual({
      name: "Widget monitor - OpenHands/agent-server-gui",
      prompt: "Report on Widgets in OpenHands/agent-server-gui.",
      repos: [{ url: "OpenHands/agent-server-gui", provider: "github" }],
      trigger: { type: "cron", schedule: "*/15 * * * *" },
    });
    expect(mocks.runAction.mock.calls[0][3]).toBe("cron");
  });

  it("draws the entry's diagram under its description", async () => {
    // Act
    renderDialog({ ...ENTRY, diagram: ENTRY_DIAGRAM });

    // Assert
    expect(await screen.findByTestId("mermaid-diagram")).toContainElement(
      screen.getByTestId("entry-diagram-svg"),
    );
  });

  it("draws no diagram for an entry without one", () => {
    // Act
    renderDialog();

    // Assert
    expect(screen.getByTestId("setup-continue-button")).toBeInTheDocument();
    expect(screen.queryByTestId("mermaid-diagram-pending")).toBeNull();
    expect(screen.queryByTestId("mermaid-diagram")).toBeNull();
  });

  it("holds an unanswered required field back from the service", async () => {
    // Arrange — nothing typed, so two required fields are still empty.
    const { user } = renderDialog();

    // Act
    await user.click(screen.getByTestId("setup-continue-button"));

    // Assert — the local check reports the field's own code rather than
    // collapsing every failure into one message, and nothing was sent.
    expect(
      screen.getByTestId("setup-field-widgetName-error"),
    ).toHaveTextContent("SETUP$VALIDATION_REQUIRED");
    expect(AutomationService.validateDraft).not.toHaveBeenCalled();
    expect(screen.queryByTestId("setup-review")).toBeNull();
    expect(mocks.tracking.trackAutomationSetupBlocked).toHaveBeenCalledWith({
      automationId: ENTRY.id,
      stage: "form",
      reason: "local_validation",
      field: "widgetName",
      errorCode: "required",
    });
  });

  it("creates from the derived payload and opens what was created", async () => {
    // Arrange
    mocks.runAction.mockResolvedValue({ response: { id: "automation-1" } });
    const { user } = renderDialog();
    await fillForm(user);

    // Act
    await user.click(screen.getByTestId("setup-continue-button"));
    await waitFor(() =>
      expect(screen.getByTestId("setup-review")).toBeInTheDocument(),
    );
    await user.click(screen.getByTestId("setup-continue-button"));

    // Assert — the action is handed the derived request body, not the raw
    // answers, and the new automation is where setup lands.
    await waitFor(() =>
      expect(mocks.navigate).toHaveBeenCalledWith("/automations/automation-1", {
        replace: true,
      }),
    );
    expect(mocks.runAction.mock.calls[0][2]).toEqual({
      name: "Widget monitor - OpenHands/agent-server-gui",
      prompt: "Report on Widgets in OpenHands/agent-server-gui.",
      repos: [{ url: "OpenHands/agent-server-gui", provider: "github" }],
      trigger: { type: "cron", schedule: "*/15 * * * *" },
    });
  });

  it("leaves a repository the deployment's runs cannot clone out of repos", async () => {
    // Arrange — the entry picks a GitHub repository and this service's runs
    // clone GitLab ones only, so the repository reaches the prompt alone.
    mocks.capabilities.mockReturnValue({
      capabilities: { ...CRON_ONLY_CAPABILITIES, repoProviders: ["gitlab"] },
      supported: true,
      unmet: [],
      isLoading: false,
    });
    mocks.runAction.mockResolvedValue({ response: { id: "automation-1" } });
    const { user } = renderDialog();
    await fillForm(user);

    // Act
    await user.click(screen.getByTestId("setup-continue-button"));
    await waitFor(() =>
      expect(screen.getByTestId("setup-review")).toBeInTheDocument(),
    );
    await user.click(screen.getByTestId("setup-continue-button"));

    // Assert — neither preflight nor creation is sent the repository.
    await waitFor(() => expect(mocks.runAction).toHaveBeenCalled());
    expect(
      vi.mocked(AutomationService.validateDraft).mock.calls[0][0].draft,
    ).not.toHaveProperty("repos");
    expect(mocks.runAction.mock.calls[0][2]).toEqual({
      name: "Widget monitor - OpenHands/agent-server-gui",
      prompt: "Report on Widgets in OpenHands/agent-server-gui.",
      trigger: { type: "cron", schedule: "*/15 * * * *" },
    });
  });

  it("waits for LLM profiles before continuing", () => {
    // Arrange — profile names come from the backend, not the manifest, so the
    // form should not validate while that closed set is still unknown.
    mocks.llmProfiles.mockReturnValue({ data: undefined, isLoading: true });

    // Act
    renderDialog(LLM_PROFILE_ENTRY);

    // Assert
    expect(mocks.llmProfiles).toHaveBeenCalledWith({ enabled: true });
    expect(screen.getByTestId("setup-continue-button")).toBeDisabled();
    expect(screen.getByTestId("setup-field-model")).toHaveAttribute(
      "role",
      "combobox",
    );
    expect(screen.getByTestId("setup-field-model")).toBeDisabled();
  });

  it("submits a selected backend LLM profile name", async () => {
    // Arrange
    mocks.llmProfiles.mockReturnValue({
      data: { profiles: [{ name: "Fast" }, { name: "Smart" }] },
      isLoading: false,
    });
    mocks.runAction.mockResolvedValue({ response: { id: "automation-1" } });
    const { user } = renderDialog(LLM_PROFILE_ENTRY);

    // Act
    const modelInput = screen.getByTestId("setup-field-model");
    expect(modelInput).toHaveAttribute("role", "combobox");
    await user.click(modelInput);
    await user.click(await screen.findByText("Smart"));
    await fillForm(user);
    await user.click(screen.getByTestId("setup-continue-button"));
    await waitFor(() =>
      expect(screen.getByTestId("setup-review")).toBeInTheDocument(),
    );
    await user.click(screen.getByTestId("setup-continue-button"));

    // Assert
    await waitFor(() => expect(mocks.runAction).toHaveBeenCalled());
    expect(mocks.runAction.mock.calls[0][2]).toEqual({
      name: "Widget monitor - OpenHands/agent-server-gui",
      model: "Smart",
      prompt: "Report on Widgets in OpenHands/agent-server-gui.",
      repos: [{ url: "OpenHands/agent-server-gui", provider: "github" }],
      trigger: { type: "cron", schedule: "*/15 * * * *" },
    });
  });

  it("tells the Super Admin setup guide when it creates an automation", async () => {
    // Arrange
    const onSetupStep = vi.fn();
    window.addEventListener(SUPER_ADMIN_SETUP_STEP_EVENT, onSetupStep);
    mocks.runAction.mockResolvedValue({ response: { id: "automation-1" } });
    const { user } = renderDialog();
    await fillForm(user);

    // Act
    await user.click(screen.getByTestId("setup-continue-button"));
    await waitFor(() =>
      expect(screen.getByTestId("setup-review")).toBeInTheDocument(),
    );
    await user.click(screen.getByTestId("setup-continue-button"));

    // Assert
    await waitFor(() => expect(onSetupStep).toHaveBeenCalledTimes(1));
    expect((onSetupStep.mock.calls[0][0] as CustomEvent).detail).toEqual({
      id: "first-automation",
    });
    window.removeEventListener(SUPER_ADMIN_SETUP_STEP_EVENT, onSetupStep);
  });

  it("does not report an automation that a conversation will create", async () => {
    // Arrange
    const onSetupStep = vi.fn();
    window.addEventListener(SUPER_ADMIN_SETUP_STEP_EVENT, onSetupStep);
    mocks.capabilities.mockReturnValue(UNSUPPORTED);
    mocks.runAction.mockResolvedValue({
      response: { conversation_id: "conv-1" },
    });
    const { user } = renderDialog(
      createSetupEntry({
        setup: createSetup({
          message: "Set this up in a conversation instead.",
        }),
      }),
    );

    // Act
    await user.click(screen.getByTestId("setup-fallback-conversation"));

    // Assert
    await waitFor(() => expect(mocks.navigate).toHaveBeenCalled());
    expect(onSetupStep).not.toHaveBeenCalled();
    window.removeEventListener(SUPER_ADMIN_SETUP_STEP_EVENT, onSetupStep);
  });

  it("offers the conversation fallback when the deployment cannot run a direct entry", async () => {
    // Arrange — capabilities answered and came up short, and the entry ships
    // a fallback-conversation seed.
    mocks.capabilities.mockReturnValue(UNSUPPORTED);
    mocks.runAction.mockResolvedValue({
      response: { conversation_id: "conv-1" },
    });
    const entry = createSetupEntry({
      setup: createSetup({
        message: "Set this up in a conversation instead.",
      }),
    });
    const { user } = renderDialog(entry);

    // Act
    await user.click(screen.getByTestId("setup-fallback-conversation"));

    // Assert — the action runs with no payload, the assisted outcome, and
    // setup lands in the conversation that will finish it.
    await waitFor(() =>
      expect(mocks.navigate).toHaveBeenCalledWith("/conversations/conv-1", {
        replace: true,
      }),
    );
    expect(mocks.runAction).toHaveBeenCalledWith(
      entry,
      expect.anything(),
      null,
      "cron",
      null,
    );
  });

  it("keeps the unsupported screen close-only when there is nothing to fall back to", () => {
    // Arrange — no skill command resolves for this entry and it declares no
    // fallback message, so a conversation would open empty-handed.
    mocks.capabilities.mockReturnValue(UNSUPPORTED);
    renderDialog();

    // Assert
    expect(screen.queryByTestId("setup-fallback-conversation")).toBeNull();
    expect(mocks.tracking.trackAutomationSetupBlocked).toHaveBeenCalledWith({
      automationId: ENTRY.id,
      stage: "prerequisites",
      reason: "webhookDelivery",
      errorCode: "unsupported",
    });
  });

  it("carries a repository typed but not added through to the review step", async () => {
    // Arrange — the list is built by adding entries, and the input still shows
    // what was typed when the user reaches for Continue.
    const { user } = renderDialog(MULTI_REPO_ENTRY);
    await user.type(screen.getByTestId("setup-field-widgetName"), "Widgets");
    await user.type(
      screen.getByTestId("setup-field-repository"),
      "OpenHands/automation",
    );

    // Act — Continue, without pressing Add or Enter first.
    await user.click(screen.getByTestId("setup-continue-button"));

    // Assert — the answer the user could still see is the one being confirmed.
    await waitFor(() =>
      expect(screen.getByTestId("setup-review")).toBeInTheDocument(),
    );
    expect(screen.getByTestId("setup-review")).toHaveTextContent(
      "OpenHands/automation",
    );
  });

  it("refuses an entry the published interface declares no way to create", async () => {
    // Arrange — a bundle entry against an interface manifest published before
    // bundles: neither endpoint it needs exists, and no answer supplies them.
    mocks.missingCreateEndpoints.mockReturnValue(["createBundle", "uploads"]);
    renderDialog(BUNDLE_ENTRY);

    // Assert — said before the form, rather than as a Continue button that
    // silently does nothing once the form is filled in.
    expect(screen.getByTestId("setup-unmet-requirements")).toHaveTextContent(
      "createBundle, uploads",
    );
    expect(screen.queryByTestId("setup-field-widgetName")).toBeNull();
    expect(mocks.tracking.trackAutomationSetupBlocked).toHaveBeenCalledWith({
      automationId: BUNDLE_ENTRY.id,
      stage: "prerequisites",
      reason: "createBundle,uploads",
      errorCode: "unsupported",
    });
  });

  it("returns a rejected create to the field the service blamed", async () => {
    // Arrange — a validation failure addressed by payload path, which only the
    // derived error map can turn back into a field.
    mocks.runAction.mockRejectedValue(
      Object.assign(new Error("Unprocessable Entity"), {
        name: "HttpError",
        status: 422,
        response: {
          detail: [
            {
              loc: ["body", "trigger", "cron", "schedule"],
              msg: "Interval is too short",
            },
          ],
        },
      }),
    );
    const { user } = renderDialog();
    await fillForm(user);

    // Act
    await user.click(screen.getByTestId("setup-continue-button"));
    await waitFor(() =>
      expect(screen.getByTestId("setup-review")).toBeInTheDocument(),
    );
    await user.click(screen.getByTestId("setup-continue-button"));

    // Assert — back on the form, with the message against `schedule` rather
    // than against the form as a whole.
    await waitFor(() =>
      expect(
        screen.getByTestId("setup-field-schedule-error"),
      ).toHaveTextContent("Interval is too short"),
    );
    expect(screen.queryByTestId("setup-review")).toBeNull();
    expect(mocks.navigate).not.toHaveBeenCalled();
    expect(mocks.tracking.trackAutomationSetupBlocked).toHaveBeenCalledWith({
      automationId: ENTRY.id,
      stage: "submit",
      reason: "service_validation",
      field: "schedule",
      errorCode: "service_error",
    });
  });

  it("omits a connected provider's secret-name field on a self-hosted instance and still names the default", async () => {
    // Arrange — OpenHands Enterprise with GitHub connected under
    // Settings > Integrations: the bundle will use that account's token, so
    // there is nothing to ask, but its config must still name a secret.
    mocks.nativeIntegrations.mockReturnValue(selfHostedGithub(true));
    mocks.runAction.mockResolvedValue({ response: { id: "automation-1" } });
    const { user } = renderDialog(SECRET_NAME_BUNDLE_ENTRY);

    // Assert — not asked, on the form or on the review step.
    expect(screen.queryByTestId("setup-field-githubTokenSecret")).toBeNull();
    await fillForm(user);
    await user.click(screen.getByTestId("setup-continue-button"));
    await waitFor(() =>
      expect(screen.getByTestId("setup-review")).toBeInTheDocument(),
    );
    expect(screen.getByTestId("setup-review")).not.toHaveTextContent(
      "GitHub token secret",
    );

    // Act
    await user.click(screen.getByTestId("setup-continue-button"));

    // Assert — the declared default still reaches the bundle and its config.
    await waitFor(() => expect(mocks.runAction).toHaveBeenCalled());
    expect(mocks.runAction.mock.calls[0][1]).toMatchObject({
      githubTokenSecret: "GITHUB_PERSONAL_ACCESS_TOKEN",
    });
    expect(mocks.runAction.mock.calls[0][2]).toMatchObject({
      template: {
        config: { github_token_secret: "GITHUB_PERSONAL_ACCESS_TOKEN" },
      },
    });
  });

  it.each([
    [
      "GitHub is not connected on a self-hosted instance",
      selfHostedGithub(false),
    ],
    [
      "GitHub is connected on OpenHands Cloud",
      { ...selfHostedGithub(true), deploymentMode: "cloud" },
    ],
  ])(
    "keeps asking for the secret name when %s",
    async (_case, integrations) => {
      // Arrange — without the connected account's token to fall back on, or
      // outside Enterprise, the field is shown as the manifest declares it.
      mocks.nativeIntegrations.mockReturnValue(integrations);
      const { user } = renderDialog(SECRET_NAME_BUNDLE_ENTRY);

      // Assert
      expect(screen.getByTestId("setup-field-githubTokenSecret")).toHaveValue(
        "GITHUB_PERSONAL_ACCESS_TOKEN",
      );
      await fillForm(user);
      await user.click(screen.getByTestId("setup-continue-button"));
      await waitFor(() =>
        expect(screen.getByTestId("setup-review")).toBeInTheDocument(),
      );
      expect(screen.getByTestId("setup-review")).toHaveTextContent(
        "GitHub token secret",
      );
    },
  );
});

it("creates a bundle with an optional selected agent profile", async () => {
  mocks.capabilities.mockReturnValue({
    capabilities: {
      ...CRON_ONLY_CAPABILITIES,
      features: ["agentProfiles", "customTarball"],
    },
    supported: true,
    unmet: [],
    isLoading: false,
  });
  const entry = {
    ...BUNDLE_ENTRY,
    requires: {
      ...BUNDLE_ENTRY.requires,
      features: ["agentProfiles", "customTarball"],
    },
  };
  const { user } = renderDialog(entry);
  await fillForm(user);
  await user.click(screen.getByTestId("automation-agent-profile"));
  await user.click(await screen.findByRole("option", { name: "Reviewer" }));
  await user.click(screen.getByTestId("setup-continue-button"));
  await waitFor(() =>
    expect(screen.getByTestId("setup-review")).toBeInTheDocument(),
  );
  await user.click(screen.getByTestId("setup-continue-button"));
  expect(mocks.runAction.mock.calls[0][1]).toMatchObject({
    agent_profile_id: "review-profile",
  });
});

it.each([false, true])(
  "respects backend profile availability (%s) in template setup",
  async (enabled) => {
    mocks.instanceConfig.mockReturnValue({
      data: { deploymentMode: "self_hosted", isAgentProfilesEnabled: enabled },
    });
    mocks.capabilities.mockReturnValue({
      capabilities: ACTION_CAPABILITIES,
      supported: true,
      unmet: [],
      isLoading: false,
    });
    renderDialog(BUNDLE_ENTRY);
    expect(Boolean(screen.queryByTestId("automation-agent-profile"))).toBe(
      enabled,
    );
  },
);

it("drops a selected profile from review and submission when backend availability changes", async () => {
  mocks.capabilities.mockReturnValue({
    capabilities: ACTION_CAPABILITIES,
    supported: true,
    unmet: [],
    isLoading: false,
  });
  const { user } = renderDialog(BUNDLE_ENTRY);
  await fillForm(user);
  await user.click(screen.getByTestId("automation-agent-profile"));
  await user.click(await screen.findByRole("option", { name: "Reviewer" }));
  mocks.instanceConfig.mockReturnValue({
    data: { deploymentMode: "self_hosted", isAgentProfilesEnabled: false },
  });
  await user.type(screen.getByTestId("setup-field-widgetName"), " updated");
  expect(
    screen.queryByTestId("automation-agent-profile"),
  ).not.toBeInTheDocument();
  await user.click(screen.getByTestId("setup-continue-button"));
  await screen.findByTestId("setup-review");
  await user.click(screen.getByTestId("setup-continue-button"));
  expect(mocks.runAction.mock.calls[0][1].agent_profile_id).toBe("");
  expect(mocks.runAction.mock.calls[0][2]).not.toHaveProperty(
    "agent_profile_id",
  );
});

it("cancels queued profile preflight when eligibility changes", async () => {
  mocks.capabilities.mockReturnValue({
    capabilities: ACTION_CAPABILITIES,
    supported: true,
    unmet: [],
    isLoading: false,
  });
  const { user, rerender } = renderDialog(BUNDLE_ENTRY);
  await fillForm(user);
  await user.click(screen.getByTestId("automation-agent-profile"));
  await user.click(await screen.findByRole("option", { name: "Reviewer" }));
  await user.click(screen.getByTestId("setup-field-widgetName"));
  await user.tab();
  vi.mocked(AutomationService.validateDraft).mockClear();
  mocks.instanceConfig.mockReturnValue({
    data: { deploymentMode: "self_hosted", isAgentProfilesEnabled: false },
  });
  rerender();
  await new Promise((resolve) => setTimeout(resolve, 500));
  expect(AutomationService.validateDraft).not.toHaveBeenCalled();
});

it("returns to form when reviewed execution inputs change", async () => {
  mocks.capabilities.mockReturnValue({
    capabilities: ACTION_CAPABILITIES,
    supported: true,
    unmet: [],
    isLoading: false,
  });
  const { user, rerender } = renderDialog(BUNDLE_ENTRY);
  await fillForm(user);
  await user.click(screen.getByTestId("automation-agent-profile"));
  await user.click(await screen.findByRole("option", { name: "Reviewer" }));
  await user.click(screen.getByTestId("setup-continue-button"));
  await screen.findByTestId("setup-review");
  mocks.instanceConfig.mockReturnValue({
    data: { deploymentMode: "self_hosted", isAgentProfilesEnabled: false },
  });
  rerender();
  expect(screen.queryByTestId("setup-review")).not.toBeInTheDocument();
  expect(mocks.runAction).not.toHaveBeenCalled();
});
