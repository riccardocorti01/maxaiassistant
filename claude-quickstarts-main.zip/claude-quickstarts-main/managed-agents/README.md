# Managed Agents quickstarts

Projects built on [Claude Managed Agents](https://platform.claude.com/docs/en/managed-agents/overview): agents Anthropic runs for you, with server-side sessions, sandboxed tools, and an event stream your app consumes. Each quickstart is a complete, runnable app that pairs Managed Agents with a real product surface.

## Quickstarts

- **[assistant-ui/](assistant-ui/)** puts a spreadsheet analyst in a
  browser chat built entirely from assistant-ui primitives. Sessions are
  the thread list and the only state: the sidebar is `sessions.list`, an
  old chat is its event log replayed through one pure reducer, and every
  built-in tool has its own card (a terminal for `bash`, source cards for
  `web_search`, a diff for `edit`, a chart for the client-executed
  `show_chart`). Bash is `always_ask`, so each command parks the session
  and renders an inline Allow/Deny gate that survives a reload. Composer
  attachments upload to the Files API and mount into the sandbox before
  the message is sent. No third-party credentials.
- **[chat-sdk/](chat-sdk/)** puts a research analyst in a
  browser chat with Vercel's Chat SDK. Each conversation is one
  persistent session (the conversation ID is the session ID); the
  analyst researches with web search and streams the final brief
  token by token over the same held response (session `event_deltas`
  previews) while a live feed shows the tool calls. No third-party
  credentials, and the same handler moves to Slack, Teams, Discord,
  Telegram, or WhatsApp by swapping the adapter.

- **[copilot-kit-ag-ui/](copilot-kit-ag-ui/)** puts a personal
  finance assistant in a CopilotKit chat over the AG-UI protocol.
  The upstream [`@ag-ui/claude-managed-agents`](https://www.npmjs.com/package/@ag-ui/claude-managed-agents)
  adapter maps each chat thread to a managed session and streams
  replies token by token. When the agent wants to show numbers it
  calls custom tools that render as interactive charts (payoff
  timelines, growth projections, budgets) inline in the
  conversation, with sliders that recompute client-side.

- **[daily-brief/](daily-brief/)** posts one short brief to Slack
  every weekday morning from your Slack channels and GitHub pull
  requests, with no host process. All six resources (agent,
  environment, two memory stores, vault, cron deployment) are files
  applied with `ant apply`, so setup is one script plus two vault
  credentials. The run steps are written to fail well unattended: a
  bookmark per source instead of "the last 24 hours", a ledger
  against repeats, a source that could not be read reported as
  unreadable rather than as a quiet day, a read-only preferences
  store the agent re-reads every run, and the Slack token as a vault
  credential the sandbox never sees.

- **[knowledge-wiki/](knowledge-wiki/)** distills a document corpus
  once into a knowledge wiki (a versioned memory store) using one
  dynamic workflow run (extractors, a resolver, analyzers, an
  organizer), then answers repeated analyst questions from the wiki
  instead of re-reading documents — with `[source | as-of]` provenance
  on every fact and a lower per-question cost. The worked
  example is a real M&A data room: the 2024 Squarespace / Permira
  take-private, fetched from public SEC EDGAR filings.

- **[linear/](linear/)** answers `@mentions` and assignments in
  Linear issues with a comment, over a stateless Bun webhook bridge
  on Linear's Agent Platform. The `AgentSessionEvent` creates a
  session with the Linear session and organization IDs stored in
  session `metadata`, the handler posts a "thought" inside Linear's
  10-second window, and the `session.status_idled` webhook reads that
  metadata back to post the reply. It installs through Linear OAuth
  with `actor=app`, the first workspace to install owns the bridge,
  and Stop in Linear interrupts the running session.

- **[mcp-server-typescript/](mcp-server-typescript/)** wraps the
  Sessions API as nine MCP tools, so Claude Desktop, Claude Code, or
  claude.ai can list the agents in your workspace, start sessions,
  and relay messages to them. Eight tools map 1:1 to endpoints, and
  `wait_for_idle` turns the event stream into one request/response
  call. It creates no agents of its own. The HTTP entrypoint binds
  loopback by default, and `ALLOWED_AGENT_IDS` limits which agents a
  bearer-token holder can reach.

- **[roadtrip-planner/](roadtrip-planner/)** plans national park
  road trips in a Next.js chat built directly on a session, with no
  chat framework and no database. It shows four API features on one
  screen: `event_deltas` token streaming through a thin SSE proxy,
  vault credentials injected at a header or in a JSON body with
  `injection_location`, a per-session model override with
  `agent_with_overrides`, and a `multiagent` coordinator that hands
  its draft to a reviewer agent on the same event stream.

- **[self-hosted-sandboxes/](self-hosted-sandboxes/)** runs sessions
  on hardware you control. A self-hosted environment is a work queue:
  a host process polls it with the environment key and starts one
  short-lived Docker container per claimed session. `docker/` is the
  all-CLI baseline; `docker-memory/` runs the Python SDK worker in the
  container so each session mounts a memory store at `/mnt/memory`
  and syncs it back, and keeps the environment key out of the
  containers with a per-session token. `archil/` swaps the containers
  for Archil persistent sandboxes that all mount one SEC EDGAR disk, so
  parallel analyst sessions work on 70 GB of filings in place.
  `openshell/` swaps the containers for NVIDIA OpenShell sandboxes, each
  confined by a `policy.yaml` to a filesystem allowlist and six routes
  on `api.anthropic.com`. It is all CLI, like `docker/`, and pipes the
  per-session token to `ant beta:worker run` over stdin so the
  environment key stays on the host.
  Five more variants start the sandbox from the
  `session.status_run_started` webhook instead of a poller, on
  Cloudflare Containers, a Cloudflare Worker with no container,
  Daytona, Modal, and Vercel Sandbox. They share one agent and
  environment, created with `ant apply .` from `webhook-demo/`.

- **[sentry/](sentry/)** runs a Sentry triage agent on a schedule
  with no host process. A deployment starts a session on a cron
  expression, the agent pulls the last 24 hours of issues through
  Sentry's hosted MCP server, asks Seer for root-cause analysis where
  it is available, and writes a user-impact-ranked report. Setup runs
  inside Claude Code with Sentry's Agent Plugin to pick the org and
  project, and a browser OAuth grant lands in a vault as a refreshable
  `mcp_oauth` credential that Anthropic injects on the MCP connection
  and refreshes; the sandbox never holds a token.

- **[sentry-autofix/](sentry-autofix/)** turns a new Sentry issue into
  a pull request. A signed Sentry webhook starts one session per issue.
  The agent reads the stack trace and Seer's root cause analysis
  through the Sentry MCP server (an `mcp_oauth` vault credential),
  reproduces the bug with a failing test in the mounted repository,
  and pushes a branch. The host opens the pull request through a
  custom tool, so the repository, the base branch, and the
  `Fixes SHOP-1A` link are never the agent's to choose, and it takes
  away the session's push access once the pull request is open. Setup
  runs inside Claude Code with Sentry's Agent Plugin to pick the org
  and project.

- **[slack/](slack/)** answers `@mentions` in Slack with a threaded
  reply, over a stateless Bun webhook bridge. The Slack event creates
  a session with the channel and thread stored in session `metadata`,
  the handler acks inside Slack's 3-second window, and the
  `session.status_idled` webhook reads that metadata back to post the
  reply. No database and no held connection.
